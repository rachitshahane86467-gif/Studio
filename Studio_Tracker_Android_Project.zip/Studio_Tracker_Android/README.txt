STUDIO TRACKER — ANDROID APK PROJECT

This project wraps the existing Studio Tracker web app in a native Android WebView shell.
It is configured for a debug APK build using GitHub Actions (cloud build).

BUILD THE APK WITHOUT A COMPUTER (using GitHub in your phone browser)
1. Sign in to GitHub or create a free account.
2. Create a new repository named Studio-Tracker. Keep it private if you prefer.
3. Upload the CONTENTS of this folder (not the outer folder itself) to the repository.
   Make sure .github/workflows/build-apk.yml is included. If GitHub's mobile upload
   interface hides dot-folders, use GitHub's website in desktop mode or upload from a PC.
4. Open the repository's Actions tab.
5. Select "Build Studio Tracker APK" and tap "Run workflow" (or push to main).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to Artifacts, and download
   "Studio-Tracker-APK".
8. Extract the downloaded artifact ZIP. Inside is app-debug.apk.
9. Open app-debug.apk on your Android phone and allow installation from that source
   if Android asks. Then tap Install.

APP DETAILS
- App name: Studio Tracker
- Package ID: com.studiotracker.app
- Minimum Android version: Android 6.0 (API 23)
- Data is stored in the app's local WebView storage on this device.
- No account, server, or internet permission is included.
- Use the app's JSON backup/export regularly. Uninstalling the app or clearing its
  storage can erase locally stored records.

NOTE
This is a debug APK for personal installation, not a Play Store release. The APK
has not been compiled or device-tested in this environment because Android SDK /
Gradle build tooling is not installed here. The GitHub Actions workflow builds it
in GitHub's hosted Android-compatible Linux environment.

FIXED BUILD NOTE
This revision includes a fallback record ID generator for Android WebView contexts where crypto.randomUUID() is unavailable, and reports storage write errors.
